'use client'
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'
import L from 'leaflet'
import { useEffect, useState } from 'react'

// Soluciona íconos rotos en Next.js
delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
})

export default function Mapa({ direccion = 'calle 10, Medellín', apiKey }) {
  const [coordenadas, setCoordenadas] = useState(null)

  useEffect(() => {
    async function buscarCoordenadas() {
      const url = `https://api.geoapify.com/v1/geocode/search?text=${encodeURIComponent(
        direccion
      )}&lang=es&apiKey=${apiKey}`

      const res = await fetch(url)
      const data = await res.json()

      if (data.features && data.features.length > 0) {
        const { lat, lon } = data.features[0].properties
        setCoordenadas([lat, lon])
      }
    }

    buscarCoordenadas()
  }, [direccion, apiKey])

  if (!coordenadas) return <p className="text-sm text-gray-500">Cargando mapa...</p>

  return (
    <MapContainer center={coordenadas} zoom={15} className="h-96 w-full rounded-md shadow-md">
      <TileLayer
        url={`https://maps.geoapify.com/v1/tile/osm-bright/{z}/{x}/{y}.png?apiKey=${apiKey}`}
        attribution='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>'
      />
      <Marker position={coordenadas}>
        <Popup>
          {direccion}
        </Popup>
      </Marker>
    </MapContainer>
  )
}
