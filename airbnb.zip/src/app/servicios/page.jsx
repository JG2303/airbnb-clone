export const metadata = {
    title: "Servicios | Airbnb",
    descripcion: "pagina de servicios ofrecidos "

}
export default function Servicios(){
    return(
        <div className="flex justify-center">
           <p>Acá va el contenido de Servicios</p>
        </div>
    )
}