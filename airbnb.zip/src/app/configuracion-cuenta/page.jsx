export default function ConfiguracionCuenta(){
    return(
        <div>
            aca va la configuracion
        </div>
    )
}