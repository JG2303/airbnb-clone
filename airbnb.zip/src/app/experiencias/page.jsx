export const metadata = {
    title: "Experiencias | Airbnb",
    descripcion : "Encuentra las mejores experiencias"
}
export default function Experiencias() {
    return(
       <div className="flex justify-center">
            <p>Aca va el contenido de experiencias</p> 
                              
        </div>
    )
}